Bootstrapping framework for the coding component of assignment 3 in
CS798 - Multicore Programming at the University of Waterloo.

Compilation:
    make -j

Run the compiled binaries to see usage instructions.
